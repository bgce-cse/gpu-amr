using TerraDG


configfile = "./advection.yaml"
TerraDG.main(configfile)
